override.pageType = "full-media"; // "text-on-left", "text-on-right", "full-media"
override.pageSize="470*400";